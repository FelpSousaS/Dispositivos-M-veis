package br.ufc.quixada.scap.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.imageview.ShapeableImageView;

import java.util.ArrayList;

import br.ufc.quixada.scap.Model.Atividades;
import br.ufc.quixada.scap.R;

public class MinhasAtividadesAdapter extends RecyclerView.Adapter<MinhasAtividadesAdapter.MyViewHolder> {
    ArrayList<Atividades> minhasAtividades;
    Context context;

    public static class MyViewHolder extends RecyclerView.ViewHolder{
        TextView txtNomeAtividade, txtNomeAutor;
        ShapeableImageView titleImage;
        ImageView itemUpdate;
        ImageView itemDelete;

        public MyViewHolder(@NonNull View itemView){
            super(itemView);
            titleImage = itemView.findViewById(R.id.title_image);
            txtNomeAtividade = itemView.findViewById(R.id.txtAtvNome);
            txtNomeAutor = itemView.findViewById(R.id.txtAtvAutor);
            itemUpdate = itemView.findViewById(R.id.itemUpdate);
            itemDelete = itemView.findViewById(R.id.itemDelete);
        }
        public TextView getTextViewNome() {
            return txtNomeAtividade;
        }
        public TextView getTextViewAutor() {
            return txtNomeAutor;
        }
        public ImageView getItemUpdate(){
            return itemUpdate;
        }
        public ImageView getItemDelete(){
            return itemDelete;
        }
    }

    public MinhasAtividadesAdapter(Context context, ArrayList<Atividades> atividades){
        this.context = context;
        this.minhasAtividades = atividades;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_atividades, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MinhasAtividadesAdapter.MyViewHolder holder, int position) {
        Atividades atv = minhasAtividades.get(position);
        holder.getTextViewNome().setText(atv.getNomeAtv());
        holder.getTextViewAutor().setText(atv.getNomeAutor());
        holder.getItemDelete().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Atividades a = minhasAtividades.get(holder.getAdapterPosition());
                MinhasAtividadesAdapter.this.notifyDataSetChanged();
            }
        });
        holder.getItemUpdate().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Atividades a = minhasAtividades.get(holder.getAdapterPosition());
                MinhasAtividadesAdapter.this.notifyDataSetChanged();
            }
        });
    }

    @Override
    public int getItemCount() {
        return minhasAtividades.size();
    }
}
