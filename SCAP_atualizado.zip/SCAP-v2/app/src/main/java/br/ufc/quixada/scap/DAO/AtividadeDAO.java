package br.ufc.quixada.scap.DAO;

import android.content.Context;

import java.util.ArrayList;

import br.ufc.quixada.scap.Model.Atividades;


public class AtividadeDAO implements SCAPInterface{
    private static ArrayList<Atividades> atividadesList = new ArrayList<>();
    private static Context context;
    private static AtividadeDAO atividadeDAO = null;

    private AtividadeDAO(Context context){
        AtividadeDAO.context = context;
    }

    public static SCAPInterface getInstance(Context context){
        if(atividadeDAO == null) atividadeDAO = new AtividadeDAO(context);

        return atividadeDAO;
    }

    @Override
    public boolean delete(int atvID) {
        boolean flag = false;
        Atividades atv = null;

        for (Atividades a : atividadesList){
            if(a.getId() == atvID){
                atv = a;
                flag = true;
                break;
            }
        }
        if(flag == true) atividadesList.remove(atv);
        return flag;
    }

    @Override
    public boolean deleteAll() {
        atividadesList.clear();
        return true;
    }

    @Override
    public boolean add(Atividades a) {
        atividadesList.add(a);
        return true;
    }

    @Override
    public boolean edit(Atividades a) {
        boolean flag = false;
        for (Atividades atv : atividadesList){
            if(atv.getId() == a.getId()){
                atv.setNomeAtv(a.getNomeAtv());
                atv.setDescricaoAtv(a.getDescricaoAtv());
                atv.setObjetivoAtv(a.getObjetivoAtv());
                atv.setMetodologiaAtv(a.getMetodologiaAtv());
                atv.setResultadosAtv(a.getResultadosAtv());
                atv.setAvaliacaoAtv(a.getAvaliacaoAtv());
                flag = true;
                break;
            }
        }
        return flag;
    }
}
