package br.ufc.quixada.scap;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import br.ufc.quixada.scap.Adapters.MinhasAtividadesAdapter;
import br.ufc.quixada.scap.Model.Atividades;

public class FormAddAtividade extends AppCompatActivity {
    int id;
    EditText editNomeAtv, editDescricaoAtv, editObjetivoAtv, editMetodologiaAtv, editResultadosAtv,editAvaliacaoAtv;
    //RadioGroup option;
    AppCompatButton btnAdd;
    ArrayList<Atividades> atividadesList;
    MinhasAtividadesAdapter adapter;
    RecyclerView recyclerViewAtividades;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form_add_atividade);
        getSupportActionBar().hide();

        id = -1;

        atividadesList = new ArrayList<Atividades>();

        editNomeAtv = findViewById(R.id.edit_nome_atividade);
        editDescricaoAtv = findViewById(R.id.edit_descricao);
        editObjetivoAtv = findViewById(R.id.edit_objetivo);
        editMetodologiaAtv = findViewById(R.id.edit_metodologia);
        editResultadosAtv = findViewById(R.id.edit_resultados);
        editAvaliacaoAtv = findViewById(R.id.edit_avaliacao);
        btnAdd = findViewById(R.id.bt_add);

       // dataInitialize();
    }

    /*private void dataInitialize() {
        if(getIntent().getExtras() != null){

        }
    }*/

    public void addAtividade(View view){
        String nomeAtv = editNomeAtv.getText().toString();
        String nomeAutor = "autor";
        String descricaoAtv = editDescricaoAtv.getText().toString();
        String  objetivoAtv = editObjetivoAtv.getText().toString();
        String metodologiaAtv = editMetodologiaAtv.getText().toString();
        String resultadosAtv = editResultadosAtv.getText().toString();
        String avaliacaoAtv = editAvaliacaoAtv.getText().toString();


        Atividades a = new Atividades(nomeAtv,nomeAutor,descricaoAtv,objetivoAtv,metodologiaAtv,resultadosAtv,avaliacaoAtv);

        atividadesList.add(a);

        adapter.notifyDataSetChanged();

        editNomeAtv.setText(" ");
        editDescricaoAtv.setText(" ");
        editObjetivoAtv.setText(" ");
        editMetodologiaAtv.setText(" ");
        editResultadosAtv.setText(" ");
        editAvaliacaoAtv.setText(" ");

        Toast.makeText( this, "Atividade Adicionada", Toast.LENGTH_LONG ).show();
    }
}