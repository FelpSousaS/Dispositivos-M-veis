package br.ufc.quixada.scap.Model;

public class Atividades {


    static int countID = -1, id;
    String nomeAtv,nomeAutor,descricaoAtv, objetivoAtv, metodologiaAtv,resultadosAtv,avaliacaoAtv;
    int title_image;

    public Atividades(String nomeAtv,String nomeAutor, String descricaoAtv, String  objetivoAtv, String metodologiaAtv, String resultadosAtv, String avaliacaoAtv ){
        this.nomeAtv = nomeAtv;
        this.nomeAutor =nomeAutor;
        this.descricaoAtv = descricaoAtv;
        this.objetivoAtv = objetivoAtv;
        this.metodologiaAtv = metodologiaAtv;
        this.resultadosAtv = resultadosAtv;
        this.avaliacaoAtv = avaliacaoAtv;
        countID++;
        this.id = countID;
    }

    public Atividades(String nomeAtv, String nomeAutor, int title_image) {
        this.nomeAtv = nomeAtv;
        this.nomeAutor = nomeAutor;
        this.title_image = title_image;
    }

    public static int getId() {
        return id;
    }

    public static void setId(int id) {
        Atividades.id = id;
    }

    public String getNomeAtv() {
        return nomeAtv;
    }

    public void setNomeAtv(String nomeAtv) {
        this.nomeAtv = nomeAtv;
    }

    public String getNomeAutor() {
        return nomeAutor;
    }

    public void setNomeAutor(String nomeAutor) {
        this.nomeAutor = nomeAutor;
    }

    public String getDescricaoAtv() {
        return descricaoAtv;
    }

    public void setDescricaoAtv(String descricaoAtv) {
        this.descricaoAtv = descricaoAtv;
    }

    public String getObjetivoAtv() {
        return objetivoAtv;
    }

    public void setObjetivoAtv(String objetivoAtv) {
        this.objetivoAtv = objetivoAtv;
    }

    public String getMetodologiaAtv() {
        return metodologiaAtv;
    }

    public void setMetodologiaAtv(String metodologiaAtv) {
        this.metodologiaAtv = metodologiaAtv;
    }

    public String getResultadosAtv() {
        return resultadosAtv;
    }

    public void setResultadosAtv(String resultadosAtv) {
        this.resultadosAtv = resultadosAtv;
    }

    public String getAvaliacaoAtv() {
        return avaliacaoAtv;
    }

    public void setAvaliacaoAtv(String avaliacaoAtv) {
        this.avaliacaoAtv = avaliacaoAtv;
    }

    public int getTitle_image() {
        return title_image;
    }

    public void setTitle_image(int title_image) {
        this.title_image = title_image;
    }

    @Override
    public String toString() {
        return "Atividade{" +
                "nomeAtv='" + nomeAtv + "\n" +
                ", descricaoAtv='" + descricaoAtv + "\n" +
                ", objetivoAtv='" + objetivoAtv + "\n" +
                ", metodologiaAtv='" + metodologiaAtv + "\n" +
                ", resultadosAtv='" + resultadosAtv + "\n" +
                ", avaliacaoAtv='" + avaliacaoAtv + "\n"
                +
                '}';
    }
}
