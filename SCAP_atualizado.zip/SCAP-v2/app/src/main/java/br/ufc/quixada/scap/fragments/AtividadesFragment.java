package br.ufc.quixada.scap.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import br.ufc.quixada.scap.Adapters.MinhasAtividadesAdapter;
import br.ufc.quixada.scap.Model.Atividades;
import br.ufc.quixada.scap.R;

public class AtividadesFragment extends Fragment {

    private RecyclerView recyclerview;
    private String[] title_atividade;
    private String [] autor;
    private int[] imageResourceID;
    ArrayList<Atividades> atividadesList;

    public AtividadesFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_atividades, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        dataInitialize();
        recyclerview = view.findViewById(R.id.lista_atividades);
        recyclerview.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerview.setHasFixedSize(true);
        MinhasAtividadesAdapter petAdapter = new MinhasAtividadesAdapter(getContext(), atividadesList);
        recyclerview.setAdapter(petAdapter);
        petAdapter.notifyDataSetChanged();

    }
    private void dataInitialize() {
        atividadesList = new ArrayList<>();
        title_atividade = new String[]{
                getString(R.string.atividade),
                getString(R.string.atividade)

        };

        imageResourceID = new int[]{
                R.drawable.projeto01,
                R.drawable.projeto02


        };

        title_atividade = getResources().getStringArray(R.array.nome_array);
        autor = getResources().getStringArray(R.array.autor_array);

        for (int i = 0; i < title_atividade.length; i++){
            Atividades atividades = new Atividades(title_atividade[i], autor[i], imageResourceID[i]);
            atividadesList.add(atividades);
        }

    }


}