package br.ufc.quixada.scap.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import androidx.appcompat.widget.AppCompatButton;
import androidx.fragment.app.Fragment;

import br.ufc.quixada.scap.R;


public class UploadFragment extends Fragment {

    public static int RESULT_ADD = 1;
    String nomeAtv,descricaoAtv, objetivoAtv, metodologiaAtv,resultadosAtv,avaliacaoAtv;
    EditText editNomeAtv, editDescricaoAtv, editObjetivoAtv, editMetodologiaAtv, editResultadosAtv,editAvaliacaoAtv;
    AppCompatButton btnAdd;
    public UploadFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        /*editNomeAtv.findViewById(R.id.edit_nome_atividade);
        editDescricaoAtv.findViewById(R.id.edit_descricao);
        editObjetivoAtv.findViewById(R.id.edit_objetivo);
        editMetodologiaAtv.findViewById(R.id.edit_metodologia);
        editResultadosAtv.findViewById(R.id.edit_resultados);
        editAvaliacaoAtv.findViewById(R.id.edit_avaliacao);

      btnAdd.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view) {
            Intent intent = new Intent();

            nomeAtv = editNomeAtv.getText().toString();
            descricaoAtv = editDescricaoAtv.getText().toString();
            objetivoAtv = editObjetivoAtv.getText().toString();
            metodologiaAtv = editMetodologiaAtv.getText().toString();
            resultadosAtv = editResultadosAtv.getText().toString();
            avaliacaoAtv = editAvaliacaoAtv.getText().toString();

            intent.putExtra("Nome da Atividade",nomeAtv);
            intent.putExtra("Descricao da Atividade", descricaoAtv);
            intent.putExtra("Objetivo da Atividade", objetivoAtv);
            intent.putExtra("Metodologia da Atividade",metodologiaAtv);
            intent.putExtra("Resultados",resultadosAtv);
            intent.putExtra("Avaliacao",avaliacaoAtv);
          }
      });*/

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        return inflater.inflate(R.layout.fragment_upload, container, false);
    }
}